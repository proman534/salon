import 'package:flutter/material.dart';

class SalonOwnerScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Salon Owner Home")),
      body: Center(child: Text("Welcome, Salon Owner!")),
    );
  }
}
